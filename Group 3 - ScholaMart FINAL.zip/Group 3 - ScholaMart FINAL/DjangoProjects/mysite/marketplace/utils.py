# marketplace/utils.py
from .models import ActivityLog

def log_activity(user, action, product_name=None):
    ActivityLog.objects.create(user=user, action=action, product_name=product_name)
