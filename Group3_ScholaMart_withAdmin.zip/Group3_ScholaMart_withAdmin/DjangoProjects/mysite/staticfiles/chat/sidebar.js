// sidebar.js
// Handles: toggle sidebar, fetch contacts, open chat popups (iframe to /chat/<room_name>/)

(function () {
  const apiContacts = '/chat/contacts/';   // endpoint (we'll add view+url)
  const apiStart = '/chat/start/';         // start chat endpoint (POST to /chat/start/<user_id>/)

  const btn = document.getElementById('chat-toggle-btn');
  const sidebar = document.getElementById('chat-sidebar');
  const closeBtn = document.getElementById('chat-close-btn');
  const contactsWrap = document.getElementById('chat-contacts');
  const unreadBadge = document.getElementById('chat-unread-badge');
  const popups = document.getElementById('chat-popups');
  const searchInput = document.getElementById('chat-search-input');

  let contacts = [];

  function toggleSidebar(open) {
    if (open) {
      sidebar.classList.add('open');
      sidebar.classList.remove('hidden');
      sidebar.setAttribute('aria-hidden', 'false');
    } else {
      sidebar.classList.remove('open');
      sidebar.classList.add('hidden');
      sidebar.setAttribute('aria-hidden', 'true');
    }
  }

  btn.addEventListener('click', () => {
    const isOpen = sidebar.classList.contains('open');
    toggleSidebar(!isOpen);
  });

  closeBtn.addEventListener('click', () => toggleSidebar(false));

  // fetch contacts (simple JSON expected)
  async function loadContacts() {
    try {
      const res = await fetch(apiContacts);
      if (!res.ok) throw new Error('contacts fetch failed');
      const data = await res.json();
      contacts = data.contacts || [];
      renderContacts(contacts);
      updateUnreadBadge();
    } catch (err) {
      contactsWrap.innerHTML = '<div class="chat-loading">Unable to load contacts</div>';
      console.error(err);
    }
  }

  function renderContacts(list) {
    if (!list.length) {
      contactsWrap.innerHTML = '<div style="padding:14px;color:#94a3b8;">No contacts found.</div>';
      return;
    }
    const q = (searchInput.value || '').toLowerCase().trim();
    const items = list.filter(c => {
      if (!q) return true;
      return (c.username || '').toLowerCase().includes(q);
    }).map(c => {
      const avatar = c.avatar_url || '/static/hello/img/default-avatar.png.png';
      const unread = c.unread || 0;
      return `
      <div class="chat-contact" data-user-id="${c.id}" data-username="${c.username}">
        <img src="${avatar}" alt="${c.username}">
        <div class="meta">
          <div class="name">${c.username}</div>
          <div class="subtitle">${c.preview || ''}${unread? ' • ' + unread + ' new':''}</div>
        </div>
      </div>
      `;
    });

    contactsWrap.innerHTML = items.join('\n');

    // attach click handlers
    contactsWrap.querySelectorAll('.chat-contact').forEach(el => {
      el.addEventListener('click', async () => {
        const uid = el.getAttribute('data-user-id');
        const uname = el.getAttribute('data-username');
        // start chat (POST)
        try {
          const resp = await fetch(apiStart + uid + '/', { method:'POST', headers: {'X-CSRFToken': getCookie('csrftoken')} });
          const json = await resp.json();
          if (json.room_name) {
            openChatPopup(uname, json.room_name);
          }
        } catch (err) {
          console.error('start chat failed', err);
        }
      });
    });
  }

  // small utility to open a popup with an iframe to the chat URL
  function openChatPopup(title, roomName) {
    // if popup exists for same roomName, focus nothing else
    if (document.querySelector(`.chat-popup[data-room="${roomName}"]`)) return;

    const popup = document.createElement('div');
    popup.className = 'chat-popup';
    popup.dataset.room = roomName;

    popup.innerHTML = `
      <div class="popup-header">
        <div class="title">${title}</div>
        <div>
          <button class="popup-minimize" title="Minimize">—</button>
          <button class="popup-close" title="Close">✕</button>
        </div>
      </div>
      <iframe src="/chat/${encodeURIComponent(roomName)}/" sandbox="allow-same-origin allow-scripts allow-forms"></iframe>
      <div class="popup-input">
        <input type="text" placeholder="Type a message..." />
        <button>Send</button>
      </div>
    `;

    // append
    popups.appendChild(popup);

    // wire close
    popup.querySelector('.popup-close').addEventListener('click', () => popup.remove());
    popup.querySelector('.popup-minimize').addEventListener('click', () => {
      popup.classList.toggle('minimized');
      const iframe = popup.querySelector('iframe');
      iframe.style.height = popup.classList.contains('minimized') ? '0px' : '280px';
    });

    // sending from popup input will post via websocket inside iframe; we simply forward to iframe's elements (the iframe page handles messaging)
    const input = popup.querySelector('.popup-input input');
    const sendBtn = popup.querySelector('.popup-input button');
    sendBtn.addEventListener('click', () => {
      const val = input.value.trim();
      if (!val) return;
      try {
        const win = popup.querySelector('iframe').contentWindow;
        // if the chat page exposes a function to receive externally (not guaranteed) — otherwise just focus the iframe
        if (win && typeof win.postMessage === 'function') {
          win.postMessage({ type: 'external_message', text: val }, window.location.origin);
        }
        input.value = '';
      } catch (e) {
        console.warn('postMessage failed', e);
      }
    });
  }

  // unread badge count
  function updateUnreadBadge() {
    const total = contacts.reduce((s,c)=> s + (c.unread || 0), 0);
    if (total > 0) {
      unreadBadge.style.display = 'inline-block';
      unreadBadge.textContent = total > 99 ? '99+' : total;
    } else {
      unreadBadge.style.display = 'none';
    }
  }

  // simple poll (refresh contacts every 20s)
  loadContacts();
  setInterval(loadContacts, 20000);

  // search
  searchInput.addEventListener('input', () => renderContacts(contacts));

  // helper: get cookie for CSRF
  function getCookie(name) {
    const v = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    return v ? v.pop() : '';
  }

})();

// ------------------------------------------------------
// OPEN CHAT WITH A USER
// Called when clicking "Message" on profiles
// ------------------------------------------------------
window.openChatWith = function (otherUserId) {
    console.log("Opening chat with user:", otherUserId);

    fetch(`/chat/start/${otherUserId}/`, {
        method: "POST",
        headers: {
            "X-CSRFToken": getCSRFToken(),
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            console.error(data.error);
            return;
        }

        const convId = data.conversation_id;
        console.log("Conversation:", convId);

        // Now open chat window
        openChatWindow(convId, otherUserId);
    })
    .catch(err => console.error(err));
};


// ------------------------------------------------------
// SIMPLE CSRF TOKEN HELPER
// ------------------------------------------------------
function getCSRFToken() {
    let cookieValue = null;
    const cookies = document.cookie.split(';');

    for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.startsWith("csrftoken=")) {
            cookieValue = cookie.substring("csrftoken=".length);
        }
    }
    return cookieValue;
}
// ===============================================================
// OPEN OR CREATE A CHAT THREAD
// Called by: openChatWith(userId)
// ===============================================================
function openChatWith(userId) {
    if (!window.CURRENT_USER_ID) {
        alert("You must be logged in to message users.");
        return;
    }

    // Call Django to create/fetch conversation
    fetch(`/chat/start/${userId}/`, {
        method: "POST",
        headers: {
            "X-CSRFToken": getCSRFToken(),
        }
    })
    .then((res) => res.json())
    .then((data) => {
        if (data.conversation_id) {
            openChatWindow(data.conversation_id);
        } else {
            console.error("Error:", data);
        }
    })
    .catch((err) => console.error(err));
}



// ===============================================================
// OPEN CHAT POPUP WINDOW UI
// ===============================================================
const openChats = {};   // keep tracking of opened chat windows

function openChatWindow(conversationId) {

    // If already open → bring to front
    if (openChats[conversationId]) {
        openChats[conversationId].style.display = "flex";
        return;
    }

    // Create popup container
    const chatWindow = document.createElement("div");
    chatWindow.className = "chat-window";
    chatWindow.dataset.conversationId = conversationId;

    chatWindow.innerHTML = `
        <div style="padding:10px;background:#0f172a;border-bottom:1px solid #334155;display:flex;justify-content:space-between;align-items:center;">
            <div style="color:#38bdf8;font-weight:bold;">Chat #${conversationId}</div>
            <button class="close-chat-btn" style="background:none;border:none;color:#94a3b8;font-size:18px;cursor:pointer;">✖</button>
        </div>

        <div class="chat-messages" id="msgs-${conversationId}">
            <div style="color:#64748b;text-align:center;margin-top:20px;">Loading...</div>
        </div>

        <div class="chat-input">
            <input id="input-${conversationId}"
                   type="text"
                   placeholder="Type a message..."
                   style="flex:1;border-radius:6px;background:#334155;color:white;border:none;padding:8px;">
            <button id="send-${conversationId}"
                    style="padding:8px 14px;background:#3b82f6;border:none;border-radius:6px;color:white;cursor:pointer;">
                Send
            </button>
        </div>
    `;

    // Add to UI
    document.getElementById("openChatsContainer").appendChild(chatWindow);
    openChats[conversationId] = chatWindow;



    // ===============================================================
    // CLOSE BUTTON
    // ===============================================================
    chatWindow.querySelector(".close-chat-btn").onclick = () => {
        chatWindow.remove();
        delete openChats[conversationId];
    };



    // ===============================================================
    // WEBSOCKET CONNECTION
    // ===============================================================
    const wsScheme = window.location.protocol === "https:" ? "wss" : "ws";
    const socket = new WebSocket(`${wsScheme}://${window.location.host}/ws/chat/${conversationId}/`);

    socket.onopen = () => {
        loadMessages(conversationId, socket);
    };

    socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === "message.receive") {
            appendMessage(conversationId, data);
        }
    };

    socket.onclose = () => {
        console.log("WebSocket closed");
    };



    // ===============================================================
    // SEND MESSAGE HANDLER
    // ===============================================================
    document.getElementById(`send-${conversationId}`).onclick = () => {
        const input = document.getElementById(`input-${conversationId}`);
        const text = input.value.trim();
        if (!text) return;

        socket.send(JSON.stringify({
            type: "message.send",
            text: text,
        }));

        input.value = "";
    };
}



// ===============================================================
// LOAD HISTORY MESSAGES
// ===============================================================
function loadMessages(conversationId, socket) {
    fetch(`/chat/messages/${conversationId}/`)
        .then((res) => res.json())
        .then((messages) => {
            const box = document.getElementById(`msgs-${conversationId}`);
            box.innerHTML = "";
            messages.forEach((msg) => appendMessage(conversationId, msg));
        });
}



// ===============================================================
// APPEND MESSAGE TO CHAT UI
// ===============================================================
function appendMessage(conversationId, msg) {
    const box = document.getElementById(`msgs-${conversationId}`);

    const isMe = (msg.sender_id === window.CURRENT_USER_ID);

    const el = document.createElement("div");
    el.className = isMe ? "msg-sent" : "msg-recv";
    el.style.marginBottom = "10px";
    el.textContent = msg.text;

    box.appendChild(el);
    box.scrollTop = box.scrollHeight;
}



// ===============================================================
// CSRF Helper
// ===============================================================
function getCSRFToken() {
    const match = document.cookie.match(/csrftoken=([^;]+)/);
    return match ? match[1] : "";
}
