from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    profile_image = models.ImageField(upload_to="profile_pics/", blank=True, null=True)
    # Override the related names for the auth m2m fields to avoid reverse accessor clashes
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='hello_customuser_set',
        related_query_name='user',
        blank=True,
        verbose_name='groups',
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.'
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='hello_customuser_permissions_set',
        related_query_name='user',
        blank=True,
        verbose_name='user permissions',
        help_text='Specific permissions for this user.'
    )

class Student(models.Model):
    student_id = models.CharField(max_length=10)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    course = models.CharField(max_length=50)
    year_level = models.IntegerField()

    def __str__(self):
        return f"{self.student_id} - {self.first_name} {self.last_name}"