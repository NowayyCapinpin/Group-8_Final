# marketplace/utils.py
from .entities.marketplace_models import ActivityLog, ChatThread
from django.contrib.auth.models import User

# --------------------------------------------
# YOUR ORIGINAL FUNCTION (UNTOUCHED)
# --------------------------------------------
def log_activity(user, action, product_name=None):
    ActivityLog.objects.create(user=user, action=action, product_name=product_name)


# --------------------------------------------
# NEW CHAT HELPER (ADDED BELOW)
# --------------------------------------------
def get_or_create_private_thread(user_a: User, user_b: User):
    """
    Returns the *single* ChatThread used for 1-on-1 messages.
    Ensures only ONE thread per user pair by ordering the IDs.
    """

    # If user messages themselves (optional behavior)
    if user_a.id == user_b.id:
        thread_qs = ChatThread.objects.filter(participants=user_a)
        if thread_qs.exists():
            return thread_qs.first()

        t = ChatThread.objects.create()
        t.participants.add(user_a)
        return t

    # Always order pair for uniqueness
    low, high = (user_a, user_b) if user_a.id < user_b.id else (user_b, user_a)

    # Find threads where BOTH are participants
    threads = ChatThread.objects.filter(participants=low).filter(participants=high)

    # Prefer exact 1-on-1 threads
    for t in threads:
        if t.participants.count() == 2:
            return t

    # Otherwise create new
    t = ChatThread.objects.create()
    t.participants.add(user_a, user_b)
    return t
