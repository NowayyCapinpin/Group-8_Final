from django import forms
from .models import Student, Course
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'quantity', 'image']


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['first_name', 'last_name', 'email', 'course']

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['name', 'code']