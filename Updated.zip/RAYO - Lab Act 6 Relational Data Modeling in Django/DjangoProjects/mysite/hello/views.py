from django.shortcuts import render, get_object_or_404, redirect
from .models import Student, Course
from .forms import StudentForm, CourseForm
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages, auth
#----------Back End LogIn/SignUp Implementation----------
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib import messages, auth
from .models import Product
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from decimal import Decimal, InvalidOperation
from django.contrib import messages
from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required
from .models import Product
# hello/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Product
from .forms import ProductForm

@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('marketplace')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form, 'product': product})

@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        product.delete()
        return redirect('marketplace')
    return render(request, 'delete_product.html', {'product': product})



def home(request):
    return render(request, "home.html")


# ---------- Course Views ----------
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'hello/course_list.html', {'courses': courses})

def course_create(request):
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm()
    return render(request, 'hello/course_form.html', {'form': form})

def course_update(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm(instance=course)
    return render(request, 'hello/course_form.html', {'form': form})

def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        course.delete()
        return redirect('course_list')
    return render(request, 'hello/course_confirm_delete.html', {'course': course})

# ---------- Student Views ----------
def student_list(request):
    students = Student.objects.select_related('course').all()
    return render(request, 'hello/student_list.html', {'students': students})

def student_create(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm()
    return render(request, 'hello/student_form.html', {'form': form})

def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm(instance=student)
    return render(request, 'hello/student_form.html', {'form': form})

def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        student.delete()
        return redirect('student_list')
    return render(request, 'hello/student_confirm_delete.html', {'student': student})

def login_signup(request):
    # Handle login form
    if request.method == 'POST':
        if 'login' in request.POST:
            username = request.POST['username']
            password = request.POST['password']

            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('marketplace')
            else:
                messages.error(request, "Invalid username or password.")

        elif 'signup' in request.POST:
            username = request.POST['username']
            email = request.POST['email']
            password = request.POST['password']

            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already taken.")
            elif User.objects.filter(email=email).exists():
                messages.error(request, "Email already registered.")
            else:
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save()
                auth.login(request, user)
                messages.success(request, "Account created successfully! You can now log in.")
                return redirect('login')

    return render(request, 'login.html')

def logout_view(request):
    """Log the user out and redirect to home."""
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')

@login_required
def marketplace(request):
    # show products only to logged-in users
    return render(request, 'marketplace.html')

@login_required
def marketplace(request):
    query = request.GET.get('q', '')  # search query
    if query:
        products = Product.objects.filter(Q(name__icontains=query) | Q(description__icontains=query))
    else:
        products = Product.objects.all().order_by('-date_posted')
    return render(request, 'marketplace.html', {'products': products, 'query': query})


from decimal import Decimal, InvalidOperation

@login_required
def add_product(request):
    if request.method == "POST":
        name = request.POST["name"]
        description = request.POST["description"]
        image = request.FILES.get("image")
        raw_price = request.POST["price"].strip().replace("₱", "").replace(",", "")

        try:
            price = Decimal(raw_price)
            if price <= 0:
                raise InvalidOperation
        except (InvalidOperation, ValueError):
            messages.error(request, "⚠ Please enter a valid positive price (numbers only).")
            return redirect("add_product")

        Product.objects.create(
            seller=request.user,
            name=name,
            description=description,
            price=price,
            image=image
        )
        messages.success(request, "✅ Product added successfully!")
        return redirect("marketplace")

    return render(request, "add_product.html")
