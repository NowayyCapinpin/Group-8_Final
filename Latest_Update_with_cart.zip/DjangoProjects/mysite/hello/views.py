from django.shortcuts import render, get_object_or_404, redirect
from .models import Student, Course, Product
from .forms import StudentForm, CourseForm, ProductForm
from django.contrib.auth.models import User
from django.contrib import messages, auth
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.db.models import Q
from decimal import Decimal, InvalidOperation


@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('marketplace')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form, 'product': product})


@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        product.delete()
        return redirect('marketplace')
    return render(request, 'delete_product.html', {'product': product})



def home(request):
    return render(request, "home.html")


# ---------- Course Views ----------
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'hello/course_list.html', {'courses': courses})


def course_create(request):
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm()
    return render(request, 'hello/course_form.html', {'form': form})


def course_update(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm(instance=course)
    return render(request, 'hello/course_form.html', {'form': form})


def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        course.delete()
        return redirect('course_list')
    return render(request, 'hello/course_confirm_delete.html', {'course': course})


# ---------- Student Views ----------
def student_list(request):
    students = Student.objects.select_related('course').all()
    return render(request, 'hello/student_list.html', {'students': students})


def student_create(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm()
    return render(request, 'hello/student_form.html', {'form': form})


def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm(instance=student)
    return render(request, 'hello/student_form.html', {'form': form})


def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        student.delete()
        return redirect('student_list')
    return render(request, 'hello/student_confirm_delete.html', {'student': student})


def login_signup(request):
    # Handle login form
    if request.method == 'POST':
        if 'login' in request.POST:
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('marketplace')
            else:
                messages.error(request, "Invalid username or password.")

        elif 'signup' in request.POST:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password1 = request.POST.get('password1')
            password2 = request.POST.get('password2')

            if password1 != password2:
                messages.error(request, "Passwords do not match.")
                return render(request, 'login.html', {'show_signup': True})

            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already taken.")
                return render(request, 'login.html', {'show_signup': True})

            if User.objects.filter(email=email).exists():
                messages.error(request, "Email already registered.")
                return render(request, 'login.html', {'show_signup': True})

            # Create new user
            user = User.objects.create_user(username=username, email=email, password=password1)
            user.save()
            messages.success(request, "Account created successfully. Please log in.")
            return redirect('login')

    return render(request, 'login.html')


def logout_view(request):
    """Log the user out and redirect to home."""
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')


@login_required
def marketplace(request):
    query = request.GET.get('q', '')  # search query
    if query:
        products = Product.objects.filter(Q(name__icontains=query) | Q(description__icontains=query))
    else:
        products = Product.objects.all().order_by('-date_posted')
    return render(request, 'marketplace.html', {'products': products, 'query': query})


@login_required
def add_product(request):
    if request.method == "POST":
        name = request.POST["name"]
        description = request.POST["description"]
        image = request.FILES.get("image")
        raw_price = request.POST["price"].strip().replace("₱", "").replace(",", "")

        try:
            price = Decimal(raw_price)
            if price <= 0:
                raise InvalidOperation
        except (InvalidOperation, ValueError):
            messages.error(request, "⚠ Please enter a valid positive price (numbers only).")
            return redirect("add_product")

        Product.objects.create(
            seller=request.user,
            name=name,
            description=description,
            price=price,
            image=image
        )
        messages.success(request, "✅ Product added successfully!")
        return redirect("marketplace")

    return render(request, "add_product.html")



from .models import Order, OrderItem
from .forms import OrderConfirmForm
from django.views.decorators.http import require_POST

@login_required
@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    # Get or create a pending order for the user
    order, created = Order.objects.get_or_create(user=request.user, status='pending')
    # Check if item exists in order
    item, item_created = OrderItem.objects.get_or_create(order=order, product=product)
    if not item_created:
        item.quantity += 1
        item.save()
    return redirect('view_cart')

@login_required
def view_cart(request):
    order = Order.objects.filter(user=request.user, status='pending').first()
    items = order.items.all() if order else []
    total = sum([it.product.price * it.quantity for it in items]) if order else 0
    return render(request, 'cart.html', {'order': order, 'items': items, 'total': total})

@login_required
@require_POST
def update_cart(request, item_id):
    item = get_object_or_404(OrderItem, id=item_id, order__user=request.user, order__status='pending')
    try:
        qty = int(request.POST.get('quantity', 1))
        if qty <= 0:
            item.delete()
        else:
            item.quantity = qty
            item.save()
    except ValueError:
        pass
    return redirect('view_cart')

@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(OrderItem, id=item_id, order__user=request.user, order__status='pending')
    item.delete()
    return redirect('view_cart')

@login_required
def confirm_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user, status='pending')
    if request.method == 'POST':
        form = OrderConfirmForm(request.POST)
        if form.is_valid():
            order.name = form.cleaned_data['name']
            order.contact_number = form.cleaned_data['contact_number']
            order.gmail = form.cleaned_data['gmail']
            order.program = form.cleaned_data['program']
            order.status = 'confirmed'
            order.save()
            return render(request, 'order_success.html', {'order': order})
    else:
        form = OrderConfirmForm(initial={
            'name': request.user.get_full_name() or request.user.username
        })
    return render(request, 'confirm_order.html', {'order': order, 'form': form})
