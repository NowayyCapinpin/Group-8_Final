from django.urls import path
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("", views.home, name="home"),   # homepage
    path('login/', views.login_signup, name='login'),
    path('marketplace/', views.marketplace, name='marketplace'),
    path('add-product/', views.add_product, name='add_product'),
    path('edit/<int:product_id>/', views.edit_product, name='edit_product'),  # ✅
    path('delete/<int:product_id>/', views.delete_product, name='delete_product'),  # ✅
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    path('cart/', views.view_cart, name='view_cart'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/update/<int:item_id>/', views.update_cart, name='update_cart'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/confirm/<int:order_id>/', views.confirm_order, name='confirm_order'),

    path('profile/', views.profile_view, name='profile'),
]

