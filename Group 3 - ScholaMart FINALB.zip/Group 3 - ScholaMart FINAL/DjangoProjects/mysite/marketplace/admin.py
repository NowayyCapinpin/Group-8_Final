from django.contrib import admin
from .models import Student, Course

admin.site.register(Student)
admin.site.register(Course)

from .models import Profile
admin.site.register(Profile)
