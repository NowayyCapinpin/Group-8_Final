from django import forms
from .models import Student, Course
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'quantity', 'image']


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['first_name', 'last_name', 'email', 'course']

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['name', 'code']


class OrderConfirmForm(forms.Form):
    name = forms.CharField(max_length=100, required=True)
    contact_number = forms.CharField(max_length=20, required=True)
    gmail = forms.EmailField(required=True)
    program = forms.CharField(max_length=50, required=True)
