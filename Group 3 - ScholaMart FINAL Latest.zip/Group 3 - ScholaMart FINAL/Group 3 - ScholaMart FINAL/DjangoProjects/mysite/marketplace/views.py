# marketplace/views.py
from datetime import timedelta
from decimal import Decimal, InvalidOperation

from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import OrderConfirmForm, ProductForm
from .models import ActivityLog, Order, OrderItem, Product, Profile
from .utils import log_activity


# -------------------------
#  Product editing + deleting
# -------------------------
@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            # 🧾 Log activity for edit
            log_activity(request.user, 'edit', product.name)
            messages.success(request, "✅ Product updated successfully!")
            return redirect('marketplace')
    else:
        form = ProductForm(instance=product)
    return render(request, 'marketplace/edit_product.html', {'form': form, 'product': product})


@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        # 🧾 Log activity before deletion
        log_activity(request.user, 'delete', product.name)
        product.delete()
        messages.success(request, "🗑️ Product deleted successfully!")
        return redirect('marketplace')
    return render(request, 'marketplace/delete_product.html', {'product': product})


# -------------------------
#  Home / Auth
# -------------------------
def home(request):
    return render(request, "marketplace/home.html")


def login_signup(request):
    # Handle login form
    if request.method == 'POST':
        if 'login' in request.POST:
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('marketplace')
            else:
                messages.error(request, "Invalid username or password.")

        elif 'signup' in request.POST:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password1 = request.POST.get('password1')
            password2 = request.POST.get('password2')

            if password1 != password2:
                messages.error(request, "Passwords do not match.")
                return render(request, 'login.html', {'show_signup': True})

            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already taken.")
                return render(request, 'login.html', {'show_signup': True})

            if User.objects.filter(email=email).exists():
                messages.error(request, "Email already registered.")
                return render(request, 'login.html', {'show_signup': True})

            # Create new user
            user = User.objects.create_user(username=username, email=email, password=password1)
            user.save()
            messages.success(request, "Account created successfully. Please log in.")
            return redirect('login')

    return render(request, "marketplace/login.html")


def logout_view(request):
    """Log the user out and redirect to home."""
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')


# -------------------------
#  Marketplace (search + sort)
# -------------------------
@login_required
def marketplace(request):
    query = request.GET.get('q', '')   # Search query
    sort = request.GET.get('sort', '') # Sorting filter

    # 🔍 Search products
    if query:
        products = Product.objects.filter(
            Q(name__icontains=query) | Q(description__icontains=query)
        )
    else:
        products = Product.objects.all()

    # 🧩 Sorting logic
    if sort == 'price_low':
        products = products.order_by('price')
    elif sort == 'price_high':
        products = products.order_by('-price')
    elif sort == 'newest':
        products = products.order_by('-date_posted')
    else:
        # Default order: newest first
        products = products.order_by('-date_posted')

    context = {
        'products': products,
        'query': query,
        'sort': sort,
    }
    return render(request, 'marketplace/marketplace.html', context)


# -------------------------
#  Add product
# -------------------------
@login_required
def add_product(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        description = request.POST.get("description", "").strip()
        image = request.FILES.get("image")
        raw_price = request.POST.get("price", "").strip().replace("₱", "").replace(",", "")

        try:
            price = Decimal(raw_price)
            if price <= 0:
                raise InvalidOperation
        except (InvalidOperation, ValueError):
            messages.error(request, "⚠ Please enter a valid positive price (numbers only).")
            return redirect("add_product")

        # ✅ Create the product
        product = Product.objects.create(
            seller=request.user,
            name=name,
            description=description,
            price=price,
            image=image
        )

        # 🧾 Log seller activity
        log_activity(request.user, 'post', product.name)
        messages.success(request, "✅ Product added successfully!")
        return redirect("marketplace")

    return render(request, "marketplace/add_product.html")


# -------------------------
#  Complete payment (mark paid)
# -------------------------
@login_required
def complete_payment(request, order_id):
    """
    This function simulates when a user successfully pays for their order.
    It marks the order as 'paid' and logs the action for each product in that order.
    """
    order = get_object_or_404(Order, id=order_id, user=request.user)

    # Mark as paid
    order.status = 'paid'
    order.save()

    # Log each product in this order as 'paid'
    for item in order.items.all():
        log_activity(request.user, 'paid', item.product.name)

    messages.success(request, "✅ Payment completed successfully!")
    return redirect("view_cart")


# -------------------------
#  Cart / Order logic
# -------------------------
@login_required
@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    # Get or create a pending order for the user
    order, created = Order.objects.get_or_create(user=request.user, status='pending')
    # Check if item exists in order
    item, item_created = OrderItem.objects.get_or_create(order=order, product=product)
    if not item_created:
        item.quantity += 1
        item.save()
    return redirect('view_cart')


@login_required
def view_cart(request):
    # ✅ Current pending order (cart)
    order = Order.objects.filter(user=request.user, status='pending').first()
    items = order.items.all() if order else []

    # Subtotal per item
    for it in items:
        it.subtotal = it.product.price * it.quantity

    total = sum(it.subtotal for it in items) if items else 0

    # ✅ Payment History Filter
    filter_days = request.GET.get('days', '7')  # default: last 7 days
    now = timezone.now()

    if filter_days == 'today':
        since = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif filter_days.isdigit():
        since = now - timedelta(days=int(filter_days))
    else:
        since = now - timedelta(days=7)

    # ✅ Filter logs (only 'paid' within the selected period)
    logs = ActivityLog.objects.filter(
        user=request.user,
        action='paid',
        timestamp__gte=since
    ).order_by('-timestamp')[:4]  # show latest 4

    # ✅ Calculate total money spent by parsing the log.product_name text if it contains ₱
    total_spent = 0
    for log in logs:
        if log.product_name and '₱' in log.product_name:
            try:
                peso_value = log.product_name.split('₱')[1].split()[0]
                peso_value = peso_value.replace(',', '')
                total_spent += float(peso_value)
            except Exception:
                continue

    context = {
        'order': order,
        'items': items,
        'total': total,
        'logs': logs,
        'filter_days': filter_days,
        'total_spent': total_spent,
    }
    return render(request, "marketplace/cart.html", context)


@login_required
@require_POST
def update_cart(request, item_id):
    item = get_object_or_404(OrderItem, id=item_id, order__user=request.user, order__status='pending')
    try:
        qty = int(request.POST.get('quantity', 1))
        if qty <= 0:
            item.delete()
        else:
            item.quantity = qty
            item.save()
    except ValueError:
        pass
    return redirect('view_cart')


@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(OrderItem, id=item_id, order__user=request.user, order__status='pending')
    item.delete()
    return redirect('view_cart')


@login_required
def confirm_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user, status='pending')

    if request.method == 'POST':
        form = OrderConfirmForm(request.POST)
        if form.is_valid():
            order.name = form.cleaned_data['name']
            order.contact_number = form.cleaned_data['contact_number']
            order.gmail = form.cleaned_data['gmail']
            order.program = form.cleaned_data['program']
            order.payment_method = request.POST.get('payment_method', 'COD')
            order.status = 'confirmed'

            # Calculate total order amount once
            total_amount = sum(item.product.price * item.quantity for item in order.items.all())

            # ✅ GCash Logic — auto-paid
            if order.payment_method == 'GCASH':
                order.payment_status = 'paid'
                order.save()

                # 💳 Log clean GCash entry with the total amount
                log_activity(
                    request.user,
                    'paid',
                    f'GCash | ₱{total_amount:.2f}'
                )

                return redirect('show_gcash_qr', order_id=order.id)

            # ✅ COD Logic — stays unpaid (pending)
            else:
                order.payment_status = 'unpaid'
                order.save()

                # 💵 Log COD as unpaid now
                log_activity(
                    request.user,
                    'unpaid',
                    f'COD | ₱{total_amount:.2f}'
                )

                return render(request, "marketplace/order_success.html", {'order': order})
    else:
        form = OrderConfirmForm(initial={
            'name': request.user.get_full_name() or request.user.username
        })

    return render(request, "marketplace/confirm_order.html", {'order': order, 'form': form})


@login_required
def show_gcash_qr(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    seller = order.items.first().product.seller if order.items.exists() else None
    profile = Profile.objects.filter(user=seller).first()

    return render(request, "marketplace/gcash_payment.html", {
        'order': order,
        'gcash_account': profile.gcash_account if profile else "No GCash info",
        'gcash_qr': profile.gcash_qr.url if profile and profile.gcash_qr else None,
    })


# -------------------------
#  PROFILE: unified views (profile + viewing other user)
# -------------------------
@login_required
def profile(request):
    """
    Owner's profile page. Uses the same template as view_user_profile (marketplace/profile.html).
    This view renders the read-only profile page. Editing is done through edit_profile.
    """
    seller = request.user
    profile_obj, _ = Profile.objects.get_or_create(user=seller)
    products = Product.objects.filter(seller=seller).order_by('-date_posted')

    return render(request, "marketplace/profile.html", {
        'profile_user': seller,
        'profile': profile_obj,
        'products': products,
        'is_self': True
    })


@login_required
def edit_profile(request):
    profile_obj, _ = Profile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        nickname = request.POST.get("nickname", profile_obj.nickname)
        contact_number = request.POST.get("contact_number", profile_obj.contact_number)
        gcash_account = request.POST.get("gcash_account", profile_obj.gcash_account)

        profile_obj.nickname = nickname
        profile_obj.contact_number = contact_number
        profile_obj.gcash_account = gcash_account

        if "avatar" in request.FILES:
            profile_obj.avatar = request.FILES["avatar"]

        if "gcash_qr" in request.FILES:
            profile_obj.gcash_qr = request.FILES["gcash_qr"]

        profile_obj.save()
        messages.success(request, "Profile updated successfully!")
        return redirect("profile")

    return render(request, "marketplace/edit_profile.html", {"profile": profile_obj})


@login_required
def view_user_profile(request, user_id):
    """
    Viewing another user's profile. Uses same profile.html template.
    The template will check `is_self` to decide whether to show Edit button.
    """
    seller = get_object_or_404(User, id=user_id)
    profile_obj, _ = Profile.objects.get_or_create(user=seller)
    products = Product.objects.filter(seller=seller).order_by('-date_posted')

    is_self = (request.user == seller)

    return render(request, "marketplace/profile.html", {
        'profile_user': seller,
        'profile': profile_obj,
        'products': products,
        'is_self': is_self
    })


# -------------------------
#  Activity log
# -------------------------
@login_required
def activity_log(request):
    logs = ActivityLog.objects.filter(user=request.user).order_by('-timestamp')
    return render(request, "marketplace/activity_log.html", {'logs': logs})
