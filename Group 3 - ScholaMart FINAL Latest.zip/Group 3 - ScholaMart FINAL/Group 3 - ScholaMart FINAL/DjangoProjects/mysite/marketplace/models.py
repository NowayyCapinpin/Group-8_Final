from django.db import models
from django.contrib.auth.models import User
from decimal import Decimal

class Product(models.Model):
    seller = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=100, decimal_places=2, default=Decimal('0.00'))
    quantity = models.PositiveIntegerField(default=1)
    image = models.ImageField(upload_to='product_images/', blank=True, null=True)
    date_posted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.seller.username}"


# --- Orders / Cart models ---
class Order(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    contact_number = models.CharField(max_length=20, blank=True, null=True)
    gmail = models.EmailField(blank=True, null=True)
    program = models.CharField(max_length=50, blank=True, null=True)

    # ✅ --- NEW PAYMENT FIELDS START ---
    PAYMENT_METHODS = [
        ('COD', 'Cash on Delivery'),
        ('GCASH', 'GCash'),
    ]
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS, default='COD')
    payment_status = models.CharField(max_length=20, default='unpaid')  # unpaid / paid
    # ✅ --- NEW PAYMENT FIELDS END ---

    def __str__(self):
        return f"Order #{self.id} - {self.user.username} - {self.status}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.product.name} (x{self.quantity})"


# --- User Profile for avatar & contact ---
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    nickname = models.CharField(max_length=100, blank=True)
    contact_number = models.CharField(max_length=20, blank=True)
    avatar = models.ImageField(upload_to='avatars/', default='avatars/default.png', blank=True)

    # ✅ --- NEW GCash FIELDS START ---
    gcash_account = models.CharField(max_length=50, blank=True, null=True)
    gcash_qr = models.ImageField(upload_to='qr_codes/', blank=True, null=True)
    # ✅ --- NEW GCash FIELDS END ---

    def __str__(self):
        return self.user.username


@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    else:
        # ensure profile exists
        Profile.objects.get_or_create(user=instance)
    try:
        instance.profile.save()
    except Exception:
        pass


class ActivityLog(models.Model):
    ACTION_TYPES = [
        ('paid', 'Paid'),
        ('unpaid', 'Unpaid'),
        ('post', 'Posted Product'),
        ('edit', 'Edited Product'),
        ('delete', 'Deleted Product'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="activity_logs")
    action = models.CharField(max_length=20, choices=ACTION_TYPES)
    product_name = models.CharField(max_length=255, null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} {self.action} {self.product_name or ''} at {self.timestamp}"
