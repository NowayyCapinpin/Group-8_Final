from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path("", views.home, name="home"),   # homepage
    path('login/', views.login_signup, name='login'),
    path('marketplace/', views.marketplace, name='marketplace'),
    path('add-product/', views.add_product, name='add_product'),
    path('edit/<int:product_id>/', views.edit_product, name='edit_product'),
    path('delete/<int:product_id>/', views.delete_product, name='delete_product'),

    # ✅ Use your custom logout view
    path('logout/', views.logout_view, name='logout'),

    # Cart routes
    path('cart/', views.view_cart, name='view_cart'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/update/<int:item_id>/', views.update_cart, name='update_cart'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/confirm/<int:order_id>/', views.confirm_order, name='confirm_order'),
    path('cart/complete/<int:order_id>/', views.complete_payment, name='complete_payment'),

    # Profile routes
    path('profile/', views.profile, name='profile'),
    path('edit-profile/', views.edit_profile, name='edit_profile'),
    path('user/<int:user_id>/', views.view_user_profile, name='view_user_profile'),

    # Activity logs
    path('activity/log/', views.activity_log, name='activity_log'),

    # GCash
    path('gcash/<int:order_id>/', views.show_gcash_qr, name='show_gcash_qr'),
]
