// static/chat/chat.js
// Full, robust chat client (websocket + message history + minimize/restore + fallback connect)
// Drop this file in static/chat/chat.js (full replacement)

console.log("CHAT JS LOADED (stable)");

window.__chat = window.__chat || {};
window.__chat.openChats = window.__chat.openChats || {};
const openChats = window.__chat.openChats;

// websocket scheme
const wsScheme = window.location.protocol === "https:" ? "wss" : "ws";

// ----------------------- utilities -----------------------
function getCSRFToken() {
  const m = document.cookie.match(/csrftoken=([^;]+)/);
  return m ? m[1] : "";
}
function parseSafeDate(s) {
  if (!s) return null;
  let d = new Date(s);
  if (!isNaN(d.getTime())) return d;
  d = new Date(String(s).replace(" ", "T"));
  return isNaN(d.getTime()) ? null : d;
}
function el(q) { return document.querySelector(q); }
function qAll(q, root=document){ return Array.from((root||document).querySelectorAll(q)); }

// ----------------------- public API -----------------------
window.openChatWith = window.openChatWith || function(userId){
  if (!window.CURRENT_USER_ID || window.CURRENT_USER_ID === "null") {
    alert("You must be logged in to message users.");
    return;
  }

  fetch(`/chat/start/${userId}/`, {
    method: "POST",
    headers: { "X-CSRFToken": getCSRFToken(), "Accept": "application/json" },
    credentials: "same-origin"
  })
  .then(r => r.json())
  .then(data => {
    const threadId = data.thread_id || data.conversation_id || data.id;
    const username = data.username || data.other_username || data.other || "Chat";
    if (threadId) openChatWindow(threadId, username);
    else {
      console.error("start chat returned unexpected:", data);
      alert("Unable to start chat (see console).");
    }
  })
  .catch(err => {
    console.error("openChatWith error", err);
    alert("Network error starting chat (see console).");
  });
};

// ----------------------- container -----------------------
function ensureContainer(){
  let c = document.getElementById("openChatsContainer");
  if (c) {
    // make sure it's styled as the floating container we expect
    c.style.position = c.style.position || "fixed";
    c.style.right = c.style.right || "20px";
    c.style.bottom = c.style.bottom || "20px";
    c.style.display = c.style.display || "flex";
    c.style.gap = c.style.gap || "12px";
    // KEY: stack windows from RIGHT to LEFT (facebook style)
    c.style.flexDirection = c.style.flexDirection || "row-reverse";
    c.style.alignItems = c.style.alignItems || "flex-end";
    c.style.zIndex = c.style.zIndex || 3000;
    c.style.pointerEvents = "auto";
    return c;
  }

  c = document.createElement("div");
  c.id = "openChatsContainer";
  c.style.position = "fixed";
  c.style.right = "20px";
  c.style.bottom = "20px";
  c.style.display = "flex";
  c.style.gap = "12px";
  // KEY: stack windows from RIGHT to LEFT (facebook style)
  c.style.flexDirection = "row-reverse";
  c.style.alignItems = "flex-end";
  c.style.zIndex = 3000;
  c.style.pointerEvents = "auto";
  document.body.appendChild(c);
  return c;
}

// ----------------------- open / create window -----------------------
function openChatWindow(threadId, username="Chat"){
  // restore if already open
  if (openChats[threadId]) {
    const existing = openChats[threadId];
    existing.style.display = "flex";
    restoreChatWindow(threadId);
    // bring to rightmost (with row-reverse this will visually move it to the right)
    const container = ensureContainer();
    container.appendChild(existing);
    return;
  }

  const container = ensureContainer();

  // window element
  const win = document.createElement("div");
  win.className = "chat-window";
  win.dataset.threadId = threadId;
  win.dataset.collapsed = "false";
  win.style.width = "360px";
  win.style.maxHeight = "420px";
  win.style.background = "#0f172a";
  win.style.border = "1px solid rgba(255,255,255,0.04)";
  win.style.borderRadius = "10px";
  win.style.boxShadow = "0 8px 30px rgba(0,0,0,0.45)";
  win.style.display = "flex";
  win.style.flexDirection = "column";
  win.style.overflow = "hidden";
  win.style.color = "#e2e8f0";
  win.style.fontFamily = "Poppins, system-ui, sans-serif";
  // let the container position the windows - flex row stacking
  win.style.pointerEvents = "auto";
  // ensure relative positioning so it sits correctly inside the flex container
  win.style.position = "relative";
  // small left margin so windows don't butt up against each other
  win.style.marginLeft = "12px";

  // header
  const header = document.createElement("div");
  header.className = "chat-header";
  header.style.padding = "10px";
  header.style.display = "flex";
  header.style.justifyContent = "space-between";
  header.style.alignItems = "center";
  header.style.borderBottom = "1px solid #334155";
  header.style.cursor = "default";

  const title = document.createElement("div");
  title.textContent = username;
  title.style.color = "#38bdf8";
  title.style.fontWeight = "700";

  const actions = document.createElement("div");
  actions.style.display = "flex";
  actions.style.gap = "8px";
  actions.style.alignItems = "center";

  const minimizeBtn = document.createElement("button");
  minimizeBtn.className = "minimize-chat-btn";
  minimizeBtn.textContent = "–";
  minimizeBtn.title = "Minimize";
  minimizeBtn.style.background = "none";
  minimizeBtn.style.border = "none";
  minimizeBtn.style.color = "#94a3b8";
  minimizeBtn.style.cursor = "pointer";

  const closeBtn = document.createElement("button");
  closeBtn.className = "close-chat-btn";
  closeBtn.textContent = "✖";
  closeBtn.title = "Close";
  closeBtn.style.background = "none";
  closeBtn.style.border = "none";
  closeBtn.style.color = "#94a3b8";
  closeBtn.style.cursor = "pointer";

  actions.appendChild(minimizeBtn);
  actions.appendChild(closeBtn);

  header.appendChild(title);
  header.appendChild(actions);

// CLICKING HEADER → RESTORE WHEN MINIMIZED
header.addEventListener("click", (e) => {
    // Don't trigger when clicking the minimize or close buttons
    if (
        e.target.classList.contains("minimize-chat-btn") ||
        e.target.classList.contains("close-chat-btn")
    ) {
        return;
    }

    if (win.dataset.collapsed === "true") {
        restoreChatWindow(threadId);
    }
});

  // messages area
  const msgBox = document.createElement("div");
  msgBox.className = "chat-messages";
  msgBox.id = `msgs-${threadId}`;
  msgBox.style.flex = "1 1 auto";
  msgBox.style.padding = "12px";
  msgBox.style.overflowY = "auto";
  msgBox.style.background = "#081024";
  msgBox.style.minHeight = "120px";

  // status area (for connection messages)
  const status = document.createElement("div");
  status.className = "chat-status";
  status.style.textAlign = "center";
  status.style.color = "#94a3b8";
  status.style.fontSize = "13px";
  status.style.padding = "8px 6px";
  status.style.display = "none";

  msgBox.appendChild(status);

  // input row
  const inputRow = document.createElement("div");
  inputRow.className = "chat-input";
  inputRow.style.display = "flex";
  inputRow.style.gap = "8px";
  inputRow.style.padding = "10px";
  inputRow.style.borderTop = "1px solid rgba(255,255,255,0.03)";

  const input = document.createElement("input");
  input.id = `input-${threadId}`;
  input.type = "text";
  input.placeholder = "Type a message...";
  input.style.flex = "1";
  input.style.padding = "8px";
  input.style.borderRadius = "6px";
  input.style.border = "none";
  input.style.background = "#14202b";
  input.style.color = "white";

  const sendBtn = document.createElement("button");
  sendBtn.id = `send-${threadId}`;
  sendBtn.textContent = "Send";
  sendBtn.style.padding = "8px 12px";
  sendBtn.style.borderRadius = "6px";
  sendBtn.style.border = "none";
  sendBtn.style.background = "#3b82f6";
  sendBtn.style.color = "white";
  sendBtn.style.cursor = "pointer";

  inputRow.appendChild(input);
  inputRow.appendChild(sendBtn);

  // assemble
  win.appendChild(header);
  win.appendChild(msgBox);
  win.appendChild(inputRow);
  container.appendChild(win);

  openChats[threadId] = win;
    saveChatState();

  minimizeBtn.onclick = (e) => {
  e.stopPropagation();
  toggleMinimize(threadId);
};

closeBtn.onclick = (e) => {
  e.stopPropagation();
  // close WS if present
  try {
    const s = win._socket;
    if (s && s.readyState === WebSocket.OPEN) s.close();
  } catch (e2){}
  win.remove();
  delete openChats[threadId];

  saveChatState();

};


  input.addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendMessage(threadId);
  });
  sendBtn.addEventListener("click", () => sendMessage(threadId));

  // create websocket with fallback
  connectSocketWithFallback(threadId, win, status);
}

// ----------------------- connect with fallback ports -----------------------
function connectSocketWithFallback(threadId, win, statusElt){
  const host = window.location.host; // includes port if any
  const hostname = window.location.hostname;
  const candidateHosts = [
    host,                        // page host (default)
    hostname + ":8001",          // common Daphne port (fallback)
    hostname + ":9001"           // another possible fallback (optional)
  ];

  // remove duplicates and invalid
  const seen = new Set();
  const hosts = candidateHosts.filter(h => {
    if (!h) return false;
    if (h === "" || seen.has(h)) return false;
    seen.add(h);
    return true;
  });

  let tried = 0;

  function tryHost(h){
    const wsUrl = `${wsScheme}://${h}/ws/chat/${threadId}/`;
    console.log("chat: trying websocket:", wsUrl);
    const socket = new WebSocket(wsUrl);

    // attach basic handlers
    socket.onerror = (ev) => {
      console.warn("chat: ws error for", wsUrl, ev);
      // try next host if present
      socket.close();
    };

    socket.onopen = () => {
      console.log("chat socket open", wsUrl);
      // store socket on window element
      win._socket = socket;
      statusElt.style.display = "none";
      loadMessages(threadId);
      // wire socket message/close
      socket.onmessage = (ev) => {
        let data;
        try { data = JSON.parse(ev.data); } catch(e){ return; }
        if (data.type === "chat.message" || data.type === "message.receive") {
          appendMessageFromSocket(threadId, data);
        }
      };
      socket.onclose = (ev) => {
        console.warn("chat socket closed", ev);
        showConnectionClosed(win);
      };
    };

    // if this host fails to open connection within a short timeout, try next
    const openTimeout = setTimeout(() => {
      if (!socket || socket.readyState === WebSocket.CLOSED || socket.readyState === WebSocket.CLOSING) {
        // try next one if available
        tried++;
        if (tried < hosts.length) {
          tryHost(hosts[tried]);
        } else {
          // all attempts failed
          console.error("chat: all websocket attempts failed (hosts tried):", hosts);
          showConnectionClosed(win, true);
        }
      } else {
        // connection succeeded or is in progress, do nothing
      }
    }, 1200); // 1.2s to detect failure/start trying next
  }

  // show a temporary "connecting..." status
  statusElt.style.display = "block";
  statusElt.textContent = "Connecting...";
  tryHost(hosts[0]);
}

// show connection closed message inside the chat
function showConnectionClosed(win, failedAll=false){
  const box = win.querySelector(".chat-messages");
  if (!box) return;
  const el = document.createElement("div");
  el.style.textAlign = "center";
  el.style.color = "#94a3b8";
  el.style.padding = "8px 6px";
  el.textContent = failedAll ? "Connection failed." : "Connection closed.";
  // avoid appending duplicates
  const existing = box.querySelector(".__conn_msg");
  if (existing) existing.remove();
  el.className = "__conn_msg";
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
  // also hide status in header if any
  const status = win.querySelector(".chat-status");
  if (status) {
    status.style.display = "none";
  }
}

// ----------------------- send message -----------------------
function sendMessage(threadId) {
  const win = openChats[threadId];
  if (!win) return;
  const socket = win._socket;
  const input = document.getElementById(`input-${threadId}`);
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;

  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: "message.send", text: text }));
  } else {
    console.error("Socket not open for thread", threadId);
    showConnectionClosed(win);
  }
  input.value = "";
}

// ----------------------- load history -----------------------
function loadMessages(threadId){
  fetch(`/chat/messages/${threadId}/`)
    .then(res => res.json())
    .then(data => {
      // expects {messages: [...] } or [...]
      let msgs = [];
      if (Array.isArray(data)) msgs = data;
      else if (Array.isArray(data.messages)) msgs = data.messages;
      else if (Array.isArray(data.messages || data)) msgs = data.messages || data;
      const box = document.getElementById(`msgs-${threadId}`);
      if (!box) return;
      // clear only message content (keep _conn_msg if present? we can clear)
      box.innerHTML = "";
      if (!Array.isArray(msgs) || msgs.length === 0) {
        const n = document.createElement("div");
        n.style.textAlign = "center";
        n.style.color = "#94a3b8";
        n.style.padding = "12px";
        n.textContent = "No messages yet";
        box.appendChild(n);
        return;
      }
      msgs.forEach(m => appendMessage(threadId, m));
      box.scrollTop = box.scrollHeight;
    })
    .catch(err => {
      console.error("loadMessages error", err);
      const box = document.getElementById(`msgs-${threadId}`);
      if (box) {
        box.innerHTML = `<div style="text-align:center;color:#ffb4b4;margin-top:18px;">Failed to load messages</div>`;
      }
    });
}

// ----------------------- renderers -----------------------
function appendMessage(threadId, msg){
  renderBubble(threadId, msg.sender_id || msg.sender || null, msg.sender_username || msg.sender_name || "", msg.text || msg.message || msg.content || "", msg.timestamp || msg.created_at || msg.date || null, msg.read);
}
function appendMessageFromSocket(threadId, data){
  renderBubble(threadId, data.sender_id || data.sender || null, data.sender_username || "", data.text || data.content || "", data.created_at || data.timestamp || null, data.read);
}

function renderBubble(threadId, senderId, senderUsername, text, created_at, seen){
  const box = document.getElementById(`msgs-${threadId}`);
  if (!box) return;

  const isMe = String(senderId) === String(window.CURRENT_USER_ID);

  const wrap = document.createElement("div");
  wrap.style.display = "flex";
  wrap.style.flexDirection = "column";
  wrap.style.maxWidth = "82%";
  wrap.style.marginBottom = "10px";
  wrap.style.alignSelf = isMe ? "flex-end" : "flex-start";

  const bubble = document.createElement("div");
  bubble.className = isMe ? "msg-sent" : "msg-recv";
  bubble.style.padding = "8px 12px";
  bubble.style.borderRadius = "14px";
  bubble.style.display = "inline-block";
  bubble.style.wordBreak = "break-word";
  bubble.style.background = isMe ? "#2563eb" : "#14202b";
  bubble.style.color = isMe ? "white" : "#e2e8f0";
  bubble.innerHTML = escapeHtml(text || "");   // no username, just message text

  const created = created_at;
  const d = parseSafeDate(created);
  const time = document.createElement("div");
  time.className = "msg-time";
  time.style.fontSize = "11px";
  time.style.color = "#94a3b8";
  time.style.marginTop = "6px";
  time.style.alignSelf = isMe ? "flex-end" : "flex-start";
  time.textContent = d ? d.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"}) : "";

  wrap.appendChild(bubble);
  wrap.appendChild(time);

  if (isMe && (seen === true || seen === "true")) {
    const seenEl = document.createElement("div");
    seenEl.className = "msg-seen";
    seenEl.style.fontSize = "11px";
    seenEl.style.color = "#94a3b8";
    seenEl.style.marginTop = "4px";
    seenEl.style.alignSelf = "flex-end";
    seenEl.textContent = "Seen ✓";
    wrap.appendChild(seenEl);
  }

  box.appendChild(wrap);
  box.scrollTop = box.scrollHeight;
}

function escapeHtml(str){
  if (!str) return "";
  return String(str)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'", "&#39;");
}

// ----------------------- minimize / restore -----------------------
function toggleMinimize(threadId){
  const w = openChats[threadId];
  if (!w) return;
  if (w.dataset.collapsed === "true") restoreChatWindow(threadId);
  else minimizeChatWindow(threadId);
}
function minimizeChatWindow(threadId){
  const w = openChats[threadId];
  if (!w) return;
  const msgs = w.querySelector(".chat-messages");
  const input = w.querySelector(".chat-input");
  if (msgs) msgs.style.display = "none";
  if (input) input.style.display = "none";
  w.style.height = "45px";
  w.dataset.collapsed = "true";
  w.classList.add("is-minimized");

  saveChatState();

}
function restoreChatWindow(threadId){
  const w = openChats[threadId];
  if (!w) return;
  const msgs = w.querySelector(".chat-messages");
  const input = w.querySelector(".chat-input");
  if (msgs) msgs.style.display = "block";
  if (input) input.style.display = "flex";
  w.style.height = ""; // allow CSS max-height
  w.dataset.collapsed = "false";
  w.classList.remove("is-minimized");
  const box = w.querySelector(".chat-messages");
  if (box) box.scrollTop = box.scrollHeight;

  saveChatState();

}

function saveChatState() {
    const state = {};

    for (const id in openChats) {
        const w = openChats[id];
        state[id] = {
            username: w.querySelector(".chat-header div").textContent,
            collapsed: w.dataset.collapsed === "true"
        };
    }

    localStorage.setItem("openChatsState", JSON.stringify(state));
}

function restoreChatState() {
    const state = JSON.parse(localStorage.getItem("openChatsState") || "{}");

    for (const id in state) {
        const chat = state[id];
        openChatWindow(id, chat.username);

        if (chat.collapsed) {
            minimizeChatWindow(id);
        }
    }
}
// ----------------------- AUTO-RESTORE ON PAGE LOAD -----------------------
document.addEventListener("DOMContentLoaded", () => {
    const url = window.location.pathname;

    // DO NOT restore chat on checkout / payment / order / user profile pages
    if (
        url.includes("/checkout") ||
        url.includes("/payment") ||
        url.includes("/place-order")
    )
     {
        console.log("Chat restore skipped on this page:", url);
        return;
    }

    restoreChatState();
});
