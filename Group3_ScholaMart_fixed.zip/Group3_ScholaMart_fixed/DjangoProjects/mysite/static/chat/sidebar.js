/* sidebar.js
   Expanded sidebar that:
   - fetches contacts from /chat/contacts/
   - starts chat via /chat/start/<user_id>/ (POST)
   - shows unread badge
   - search/filter contacts
   - opens chat via:
       1) prefer global openChatWindow / openChatWith (provided by chat.js)
       2) fallback to an iframe popup (legacy mode)
   - robust: avoids duplicate globals, defensive checks
*/

(function () {
  console.log("CHAT SIDEBAR (expanded) loaded");

  // ---------- Config ----------
  const CONTACTS_API = "/chat/contacts/";     // GET -> { contacts: [...] }
  const START_API_BASE = "/chat/start/";      // POST -> /chat/start/<user_id>/
  const POLL_INTERVAL = 20000;                // ms

  // popup mode: "useChatJs" means call openChatWith/openChatWindow (preferred)
  // if those functions aren't present, fallback to "iframe" mode automatically.
  const PREFERRED_OPEN_MODE = "useChatJs"; // "iframe" or "useChatJs"

  // ---------- DOM Handles (expected markup in _chat_sidebar.html) ----------
  const btn = document.getElementById("chat-toggle-btn");
  const sidebar = document.getElementById("chat-sidebar");
  const closeBtn = document.getElementById("chat-close-btn");
  const contactsWrap = document.getElementById("chat-contacts");
  const unreadBadge = document.getElementById("chat-unread-badge");
  const popupsWrap = document.getElementById("chat-popups");
  const searchInput = document.getElementById("chat-search-input");

  // defensive: if some elements missing, create minimal fallbacks
  if (!contactsWrap) {
    console.warn("chat: contactsWrap not found, creating fallback container");
    const el = document.createElement("div");
    el.id = "chat-contacts";
    if (sidebar) sidebar.appendChild(el);
  }
  if (!popupsWrap) {
    const p = document.createElement("div");
    p.id = "chat-popups";
    document.body.appendChild(p);
  }

  // ---------- State ----------
  let contacts = [];
  let lastFetchAt = 0;

  // ---------- Utilities ----------
  function getCSRFToken() {
    const match = document.cookie.match(/(^|;)\s*csrftoken=([^;]+)/);
    return match ? match[2] : "";
  }

  function el(selector) {
    return document.querySelector(selector);
  }

  function qAll(selector, root=document) {
    return Array.from(root.querySelectorAll(selector));
  }

  // ---------- Sidebar open/close ----------
  if (btn) {
    btn.addEventListener("click", () => {
      const isOpen = sidebar && sidebar.classList.contains("open");
      if (isOpen) closeSidebar(); else openSidebar();
    });
  }
  if (closeBtn) closeBtn.addEventListener("click", closeSidebar);

  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add("open");
    sidebar.classList.remove("hidden");
    sidebar.setAttribute("aria-hidden", "false");
  }
  function closeSidebar() {
    if (!sidebar) return;
    sidebar.classList.remove("open");
    sidebar.setAttribute("aria-hidden", "true");
  }

  // ---------- Fetch contacts ----------
  async function loadContacts() {
    try {
      const resp = await fetch(CONTACTS_API, { credentials: "same-origin" });
      if (!resp.ok) throw new Error("contacts fetch failed");
      const data = await resp.json();
      contacts = data.contacts || [];
      lastFetchAt = Date.now();
      renderContacts();
      updateUnreadBadge();
    } catch (err) {
      console.error("chat: loadContacts error", err);
      if (contactsWrap) {
        contactsWrap.innerHTML = `<div class="chat-loading" style="padding:12px;color:#94a3b8">Unable to load contacts</div>`;
      }
    }
  }

  // ---------- Render contacts ----------
  function renderContacts() {
    if (!contactsWrap) return;
    const q = (searchInput && searchInput.value || "").toLowerCase().trim();

    const list = contacts.filter(c => {
      if (!q) return true;
      const uname = (c.username || "").toLowerCase();
      const subtitle = (c.preview || "").toLowerCase();
      return uname.includes(q) || subtitle.includes(q);
    });

    if (!list.length) {
      contactsWrap.innerHTML = `<div style="padding:12px;color:#94a3b8">No contacts</div>`;
      return;
    }

    const items = list.map(c => {
      // normalize avatar url
      const avatar = c.avatar_url || "/static/hello/img/default-avatar.png";
      const unread = c.unread || 0;
      const preview = c.preview ? escapeHtml(c.preview) : "";
      return `
        <div class="chat-contact" data-user-id="${c.id}" data-username="${escapeHtml(c.username || 'user')}" role="button" tabindex="0">
          <img src="${avatar}" alt="${escapeHtml(c.username || 'avatar')}">
          <div class="meta">
            <div class="name">${escapeHtml(c.username || '')}</div>
            <div class="subtitle">${preview}${unread ? ' · ' + unread + ' new' : ''}</div>
          </div>
        </div>
      `;
    }).join("");

    contactsWrap.innerHTML = items;

    // attach handlers
    qAll(".chat-contact", contactsWrap).forEach(node => {
      node.addEventListener("click", onContactClick);
      node.addEventListener("keypress", (e) => {
        if (e.key === "Enter" || e.key === " ") onContactClick.call(node, e);
      });
    });
  }

  // ---------- click handler ----------
  async function onContactClick(e) {
    const node = this || (e.currentTarget || e.target);
    const uid = node.getAttribute("data-user-id");
    const uname = node.getAttribute("data-username") || "";

    // prefer using global openChatWith / openChatWindow if available (chat.js)
    const haveChatJs = typeof window.openChatWith === "function" || typeof window.openChatWindow === "function";

    if (PREFERRED_OPEN_MODE === "useChatJs" && haveChatJs) {
      // if we only have openChatWith that accepts userId -> call it
      try {
        if (typeof window.openChatWith === "function") {
          window.openChatWith(uid);
          return;
        }
        // else, request conversation via POST then call openChatWindow(convId, username)
        const conv = await startConversation(uid);
        if (conv && conv.conversation_id) {
          if (typeof window.openChatWindow === "function") {
            window.openChatWindow(conv.conversation_id, uname || conv.username || "Chat");
            return;
          }
        }
      } catch (err) {
        console.warn("chat: preferred open via chat.js failed, falling back to iframe", err);
      }
    }

    // fallback: start conversation (POST) then open iframe popup to /chat/<conv>/
    try {
      const conv = await startConversation(uid);
      if (conv && conv.conversation_id) {
        openIframePopup(conv.conversation_id, uname || conv.username || "Chat");
      } else if (conv && conv.room_name) {
        openIframePopup(conv.room_name, uname || conv.username || "Chat");
      } else {
        console.error("chat: startConversation returned unexpected payload", conv);
      }
    } catch (err) {
      console.error("chat: starting conversation failed", err);
    }
  }

  // ---------- start conversation helper ----------
  async function startConversation(userId) {
    const resp = await fetch(START_API_BASE + userId + "/", {
      method: "POST",
      headers: { "X-CSRFToken": getCSRFToken(), "Accept": "application/json" },
      credentials: "same-origin"
    });
    if (!resp.ok) {
      const text = await resp.text().catch(()=>"");
      throw new Error("startConversation failed: " + resp.status + " " + text);
    }
    const data = await resp.json();
    return data;
  }

  // ---------- unread badge ----------
  function updateUnreadBadge() {
    if (!unreadBadge) return;
    const total = contacts.reduce((s, c) => s + (c.unread || 0), 0);
    if (total > 0) {
      unreadBadge.style.display = "inline-block";
      unreadBadge.textContent = total > 99 ? "99+" : String(total);
    } else {
      unreadBadge.style.display = "none";
    }
  }

  // ---------- iframe popup system (fallback) ----------
  // Creates a small popup with iframe src `/chat/<room>/`
  function openIframePopup(roomName, title) {
    // Normalize roomName (escape)
    const safeRoom = encodeURIComponent(String(roomName));

    // If popup already exists for this room -> focus/show
    let existing = document.querySelector(`.chat-popup[data-room="${safeRoom}"]`);
    if (existing) {
      existing.classList.remove("minimized");
      existing.style.display = "flex";
      return;
    }

    const popup = document.createElement("div");
    popup.className = "chat-popup";
    popup.dataset.room = safeRoom;
    popup.innerHTML = `
      <div class="popup-header">
        <div class="title">${escapeHtml(title || "Chat")}</div>
        <div class="actions">
          <button class="popup-minimize" title="Minimize">—</button>
          <button class="popup-close" title="Close">✕</button>
        </div>
      </div>
      <iframe src="/chat/${safeRoom}/" sandbox="allow-same-origin allow-scripts allow-forms"></iframe>
      <div class="popup-input">
        <input type="text" placeholder="Type a message..." />
        <button class="popup-send">Send</button>
      </div>
    `;

    // append to popupsWrap
    const wrap = document.getElementById("chat-popups") || (function(){ const d=document.createElement("div"); d.id="chat-popups"; document.body.appendChild(d); return d; })();
    wrap.appendChild(popup);

    // wire buttons
    popup.querySelector(".popup-close").addEventListener("click", () => popup.remove());
    popup.querySelector(".popup-minimize").addEventListener("click", () => {
      popup.classList.toggle("minimized");
      const iframe = popup.querySelector("iframe");
      iframe.style.height = popup.classList.contains("minimized") ? "0px" : "320px";
    });

    // send from popup to iframe using postMessage
    const sendBtn = popup.querySelector(".popup-send");
    const input = popup.querySelector(".popup-input input");
    sendBtn.addEventListener("click", () => {
      const text = input.value.trim();
      if (!text) return;
      const iframe = popup.querySelector("iframe");
      try {
        iframe.contentWindow.postMessage({ type: "external_message", text }, window.location.origin);
        input.value = "";
      } catch (err) {
        console.warn("chat: postMessage failed", err);
      }
    });
  }

  // ---------- escape helper ----------
  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  // ---------- polling + init ----------
  loadContacts();
  const intervalId = setInterval(loadContacts, POLL_INTERVAL);

  // expose for debugging
  window.__chatSidebar = window.__chatSidebar || {};
  window.__chatSidebar.reloadContacts = loadContacts;
  window.__chatSidebar.stopPolling = () => clearInterval(intervalId);

  // ---------- search input wiring (if exists) ----------
  if (searchInput) {
    searchInput.addEventListener("input", () => renderContacts());
  }

  // ---------- try to update some minimal UI if elements not present ----------
  if (!btn && typeof console !== "undefined") {
    console.warn("chat sidebar toggle button (#chat-toggle-btn) not found in DOM.");
  }

  // ---------- Done ----------
})();
