console.log("CHAT SYSTEM READY (clean version)");

// ----------------------------------------------------------------------
// GLOBAL STATE
// ----------------------------------------------------------------------
const wsScheme = window.location.protocol === "https:" ? "wss" : "ws";
const openChats = {}; // active chat popup windows


// ======================================================================
// MAIN: OPEN CHAT WITH USER (called from profile or sidebar)
// ======================================================================
window.openChatWith = function (userId) {
    if (!window.CURRENT_USER_ID) {
        alert("You must be logged in to message users.");
        return;
    }

    fetch(`/chat/start/${userId}/`, {
        method: "POST",
        headers: { "X-CSRFToken": getCSRFToken() }
    })
        .then(res => res.json())
        .then(data => {
            if (data.conversation_id) {
                openChatWindow(data.conversation_id, data.username);
            } else {
                console.error("Start chat failed:", data);
            }
        })
        .catch(err => console.error(err));
};


// ======================================================================
// CREATE CHAT POPUP
// ======================================================================
function openChatWindow(conversationId, username = "Chat") {

    // Already open → show it
    if (openChats[conversationId]) {
        openChats[conversationId].style.display = "flex";
        return;
    }

    // Create popup
    const chatWindow = document.createElement("div");
    chatWindow.className = "chat-window";
    chatWindow.dataset.conversationId = conversationId;

    chatWindow.innerHTML = `
        <div style="padding:10px;background:#0f172a;border-bottom:1px solid #334155;
                    display:flex;justify-content:space-between;align-items:center;">
            <div style="color:#38bdf8;font-weight:bold;">
                ${username}
            </div>
            <button class="close-chat-btn"
                    style="background:none;border:none;color:#94a3b8;font-size:18px;cursor:pointer;">
                ✖
            </button>
        </div>

        <div class="chat-messages" id="msgs-${conversationId}">
            <div style="color:#64748b;text-align:center;margin-top:20px;">Loading...</div>
        </div>

        <div class="chat-input">
            <input id="input-${conversationId}"
                   type="text"
                   placeholder="Type a message..."
                   style="flex:1;border-radius:6px;background:#334155;color:white;border:none;padding:8px;">
            <button id="send-${conversationId}"
                    style="padding:8px 14px;background:#3b82f6;border:none;border-radius:6px;color:white;cursor:pointer;">
                Send
            </button>
        </div>
    `;

    document.getElementById("openChatsContainer").appendChild(chatWindow);
    openChats[conversationId] = chatWindow;


    // Close button
    chatWindow.querySelector(".close-chat-btn").onclick = () => {
        chatWindow.remove();
        delete openChats[conversationId];
    };


    // ==================================================================
    // WEBSOCKET
    // ==================================================================
    const socket = new WebSocket(
        `${wsScheme}://${window.location.host}/ws/chat/${conversationId}/`
    );

    socket.onopen = () => {
        loadMessages(conversationId);
        markConversationRead(conversationId);
    };

    socket.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === "chat.message") {
        appendMessage(conversationId, data);
    }
};


    // SEND button
    document.getElementById(`send-${conversationId}`).onclick = () => {
        sendSocketMessage(conversationId, socket);
    };

    // ENTER key
    document
        .getElementById(`input-${conversationId}`)
        .addEventListener("keypress", (e) => {
            if (e.key === "Enter") sendSocketMessage(conversationId, socket);
        });
}


// ======================================================================
// SEND MESSAGE THROUGH WEBSOCKET
// ======================================================================
function sendSocketMessage(conversationId, socket) {
    const input = document.getElementById(`input-${conversationId}`);
    const text = input.value.trim();
    if (!text) return;

    socket.send(
        JSON.stringify({
            type: "message.send",
            text: text,
        })
    );

    input.value = "";
}


// ======================================================================
// LOAD MESSAGE HISTORY
// ======================================================================
function loadMessages(conversationId) {
    fetch(`/chat/messages/${conversationId}/`)
        .then((res) => res.json())
        .then((messages) => {
            const box = document.getElementById(`msgs-${conversationId}`);
            box.innerHTML = "";

            messages.forEach((msg) => appendMessage(conversationId, msg));

            box.scrollTop = box.scrollHeight;
        });
}


// ======================================================================
// RENDER ONE MESSAGE
// ======================================================================
function appendMessage(conversationId, msg) {
    const box = document.getElementById(`msgs-${conversationId}`);

    const isMe = msg.sender_id === window.CURRENT_USER_ID;

    const el = document.createElement("div");
    el.className = isMe ? "msg-sent" : "msg-recv";
    el.style.marginBottom = "10px";
    el.textContent = msg.text;

    box.appendChild(el);
    box.scrollTop = box.scrollHeight;
}


// ======================================================================
// UNREAD & CSRF
// ======================================================================
function markConversationRead(convId) {
    fetch(`/chat/read/${convId}/`, {
        method: "POST",
        headers: { "X-CSRFToken": getCSRFToken() }
    }).catch(err => console.error(err));
}

function getCSRFToken() {
    const match = document.cookie.match(/csrftoken=([^;]+)/);
    return match ? match[1] : "";
}
