# marketplace/consumers.py
import bleach
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from .models import ChatThread, ChatMessage

User = get_user_model()

ALLOWED_TAGS = []
ALLOWED_ATTRS = {}


class ChatConsumer(AsyncJsonWebsocketConsumer):

    async def connect(self):
        user = self.scope.get("user")
        if not user or user.is_anonymous:
            await self.close()
            return

        # ✔ CORRECT VARIABLE NAME for routing
        self.thread_id = self.scope["url_route"]["kwargs"].get("thread_id")
        if not self.thread_id:
            await self.close()
            return

        # Check if user belongs in this thread
        is_participant = await database_sync_to_async(self._is_participant)()
        if not is_participant:
            await self.close()
            return

        self.room_group = f"chatthread_{self.thread_id}"

        await self.channel_layer.group_add(self.room_group, self.channel_name)
        await self.accept()

    def _is_participant(self):
        try:
            thread = ChatThread.objects.get(id=self.thread_id)
        except ChatThread.DoesNotExist:
            return False
        return self.scope["user"] in thread.participants.all()

    async def disconnect(self, close_code):
        if hasattr(self, "room_group"):
            await self.channel_layer.group_discard(self.room_group, self.channel_name)

    async def receive_json(self, content, **kwargs):
        """
        Expect:
        {
            "type": "message.send",
            "text": "hello!"
        }
        """
        if content.get("type") != "message.send":
            return

        raw = content.get("text", "").strip()
        if not raw:
            return

        safe = bleach.clean(raw, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRS, strip=True)
        msg = await database_sync_to_async(self._create_message)(safe)

        # Broadcast to group
        await self.channel_layer.group_send(
            self.room_group,
            {
                "type": "chat.message",
                "message_id": msg.id,
                "sender_id": msg.sender.id,
                "sender_username": msg.sender.username,
                "text": msg.text,
                "created_at": msg.timestamp.isoformat(),
            },
        )

    def _create_message(self, text):
        user = self.scope["user"]
        thread = ChatThread.objects.get(id=self.thread_id)
        return ChatMessage.objects.create(thread=thread, sender=user, text=text)

    async def chat_message(self, event):
        """Send message back to WS front-end"""
        await self.send_json(
            {
                "type": "chat.message",
                "message_id": event["message_id"],
                "sender_id": event["sender_id"],
                "sender_username": event["sender_username"],
                "text": event["text"],
                "created_at": event["created_at"],
            }
        )
