# marketplace/views.py
from datetime import timedelta
from decimal import Decimal, InvalidOperation

from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from django.db import IntegrityError
from django.http import HttpResponseRedirect, JsonResponse, HttpResponseForbidden
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST, require_GET
from django.views.decorators.csrf import csrf_exempt

from .forms import OrderConfirmForm, ProductForm
from .models import ActivityLog, Order, OrderItem, Product, Profile, Follow, ChatThread, ChatMessage
from .utils import log_activity

# -------------------------
#  Product editing + deleting
# -------------------------
@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            log_activity(request.user, 'edit', product.name)
            messages.success(request, "✅ Product updated successfully!")
            return redirect('marketplace')
    else:
        form = ProductForm(instance=product)
    return render(request, 'marketplace/edit_product.html', {'form': form, 'product': product})


@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    if request.method == 'POST':
        log_activity(request.user, 'delete', product.name)
        product.delete()
        messages.success(request, "🗑️ Product deleted successfully!")
        return redirect('marketplace')
    return render(request, 'marketplace/delete_product.html', {'product': product})


# -------------------------
#  Home / Auth
# -------------------------
def home(request):
    return render(request, "marketplace/home.html")


def login_signup(request):
    if request.method == 'POST':
        if 'login' in request.POST:
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = auth.authenticate(username=username, password=password)
            if user:
                auth.login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('marketplace')
            else:
                messages.error(request, "Invalid username or password.")

        elif 'signup' in request.POST:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password1 = request.POST.get('password1')
            password2 = request.POST.get('password2')

            if password1 != password2:
                messages.error(request, "Passwords do not match.")
                return render(request, 'login.html', {'show_signup': True})

            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already taken.")
                return render(request, 'login.html', {'show_signup': True})

            if User.objects.filter(email=email).exists():
                messages.error(request, "Email already registered.")
                return render(request, 'login.html', {'show_signup': True})

            user = User.objects.create_user(username=username, email=email, password=password1)
            messages.success(request, "Account created successfully. Please log in.")
            return redirect('login')

    return render(request, "marketplace/login.html")


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')


def marketplace(request):
    query = request.GET.get('q', '').strip()
    sort = request.GET.get('sort', '')

    products = Product.objects.none()
    users = User.objects.none()

    if query:
        products = Product.objects.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query)
        )

        users = User.objects.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query)
        ).exclude(is_superuser=True)

        if products.exists():
            if sort == 'price_low':
                products = products.order_by('price')
            elif sort == 'price_high':
                products = products.order_by('-price')
            elif sort == 'newest':
                products = products.order_by('-date_posted')
            else:
                products = products.order_by('-date_posted')

    else:
        products = Product.objects.all().order_by('-date_posted')

    return render(request, 'marketplace/marketplace.html', {
        'products': products,
        'users': users,
        'query': query,
        'sort': sort,
    })


# -------------------------
# Add product
# -------------------------
@login_required
def add_product(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        description = request.POST.get("description", "").strip()
        image = request.FILES.get("image")
        raw_price = request.POST.get("price", "").strip().replace("₱", "").replace(",", "")

        try:
            price = Decimal(raw_price)
            if price <= 0:
                raise InvalidOperation
        except Exception:
            messages.error(request, "⚠ Invalid price.")
            return redirect("add_product")

        product = Product.objects.create(
            seller=request.user,
            name=name,
            description=description,
            price=price,
            image=image
        )

        log_activity(request.user, 'post', product.name)
        messages.success(request, "✅ Product added successfully!")
        return redirect("marketplace")

    return render(request, "marketplace/add_product.html")


# -------------------------
#  Cart / Order logic
# -------------------------
@login_required
@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    pending_orders = Order.objects.filter(user=request.user, status='pending')

    if pending_orders.count() > 1:
        latest = pending_orders.latest('id')
        pending_orders.exclude(id=latest.id).delete()
        order = latest
    elif pending_orders.count() == 1:
        order = pending_orders.first()
    else:
        order = Order.objects.create(user=request.user, status='pending')

    item, created = OrderItem.objects.get_or_create(order=order, product=product)

    if not created:
        item.quantity += 1
        item.save()

    return redirect('view_cart')


@login_required
def view_cart(request):
    order = Order.objects.filter(user=request.user, status='pending').first()
    items = order.items.all() if order else []

    for it in items:
        it.subtotal = it.product.price * it.quantity

    total = sum(it.subtotal for it in items) if items else 0

    # -----------------------------
    #  FILTER HANDLING
    # -----------------------------
    filter_days = request.GET.get('days', '7')
    now = timezone.now()

    # Determine time range
    if filter_days == 'today':
        since = now.replace(hour=0, minute=0, second=0, microsecond=0)
        limit = 10

    elif filter_days == '7':
        since = now - timedelta(days=7)
        limit = 10

    elif filter_days == '30':
        since = now - timedelta(days=30)
        limit = 15

    elif filter_days == '60':
        since = now - timedelta(days=60)
        limit = 15

    elif filter_days == '90':
        since = now - timedelta(days=90)
        limit = 20

    elif filter_days == 'all':
        since = timezone.make_aware(timezone.datetime.min)
        limit = None  # unlimited

    else:
        since = now - timedelta(days=7)
        limit = 10

    # -----------------------------
    #  LOG FETCH
    # -----------------------------
    logs_qs = ActivityLog.objects.filter(
        user=request.user,
        action='paid',
        timestamp__gte=since
    ).order_by('-timestamp')

    # Apply limit only if not "show all"
    logs = logs_qs if limit is None else logs_qs[:limit]

    # -----------------------------
    #  Total spent calculation
    # -----------------------------
    total_spent = 0
    for log in logs:
        if log.product_name and '₱' in log.product_name:
            try:
                peso = log.product_name.split('₱')[1]
                peso = ''.join(ch for ch in peso if (ch.isdigit() or ch == '.' or ch == ','))
                total_spent += float(peso.replace(',', ''))
            except:
                pass

    return render(request, "marketplace/cart.html", {
        'order': order,
        'items': items,
        'total': total,
        'logs': logs,
        'filter_days': filter_days,
        'total_spent': total_spent,
    })


@login_required
def checkout_single(request, item_id):
    cart_item = get_object_or_404(
        OrderItem,
        id=item_id,
        order__user=request.user,
        order__status='pending'
    )

    subtotal = cart_item.product.price * cart_item.quantity

    single_order = Order.objects.create(
        user=request.user,
        status='pending',
        payment_status='unpaid'
    )

    OrderItem.objects.create(
        order=single_order,
        product=cart_item.product,
        quantity=cart_item.quantity
    )

    cart_item.delete()

    return redirect('confirm_order', single_order.id)


@login_required
@require_POST
def update_cart(request, item_id):
    item = get_object_or_404(OrderItem, id=item_id, order__user=request.user, order__status='pending')
    try:
        qty = int(request.POST.get('quantity', 1))
        if qty <= 0:
            item.delete()
        else:
            item.quantity = qty
            item.save()
    except Exception:
        pass
    return redirect('view_cart')


@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(OrderItem, id=item_id, order__user=request.user, order__status='pending')
    item.delete()
    return redirect('view_cart')


@login_required
def confirm_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user, status='pending')

    if request.method == 'POST':
        form = OrderConfirmForm(request.POST)
        if form.is_valid():
            order.name = form.cleaned_data['name']
            order.contact_number = form.cleaned_data['contact_number']
            order.gmail = form.cleaned_data['gmail']
            order.program = form.cleaned_data['program']
            order.payment_method = request.POST.get('payment_method', 'COD')
            order.status = 'confirmed'

            total_amount = sum(item.product.price * item.quantity for item in order.items.all())

            if order.payment_method == 'GCASH':
                order.payment_status = 'paid'
                order.save()

                item_names = ", ".join([f"{i.product.name} (₱{i.product.price} x {i.quantity})" for i in order.items.all()])
                log_activity(request.user, 'paid', f'GCash | {item_names} | Total ₱{total_amount:.2f}')

                return redirect('show_gcash_qr', order_id=order.id)

            else:
                order.payment_status = 'unpaid'
                order.save()
                item_names = ", ".join([f"{i.product.name} (₱{i.product.price} x {i.quantity})" for i in order.items.all()])
                log_activity(request.user, 'unpaid', f'COD | {item_names} | Total ₱{total_amount:.2f}')
                return render(request, "marketplace/order_success.html", {'order': order})
    else:
        form = OrderConfirmForm(initial={'name': request.user.get_full_name() or request.user.username})

    return render(request, "marketplace/confirm_order.html", {'order': order, 'form': form})


@login_required
def show_gcash_qr(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    seller = order.items.first().product.seller if order.items.exists() else None
    profile = Profile.objects.filter(user=seller).first()

    return render(request, "marketplace/show_gcash_qr.html", {
        'order': order,
        'gcash_account': profile.gcash_account if profile else None,
        'gcash_qr': profile.gcash_qr.url if profile and profile.gcash_qr else None,
    })


@login_required
@require_POST
def complete_payment(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    order.payment_status = 'paid'
    order.status = 'paid'
    order.save()

    item_details = ", ".join([f"{i.product.name} (₱{i.product.price} x {i.quantity})" for i in order.items.all()])
    log_activity(request.user, 'paid', f'GCash Payment | {item_details} | Total ₱{order.total_price if hasattr(order, "total_price") else ""}')

    messages.success(request, "Payment confirmed. Thank you!")
    return redirect('payment_success', order_id=order.id)


@login_required
def payment_success(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, "marketplace/payment_success.html", {'order': order})


def gcash_payment(request, order_id):
    order = get_object_or_404(Order, id=order_id)

    seller = order.seller

    if not seller:
        first_item = order.items.first()
        seller = first_item.product.seller

    seller_profile = seller.profile

    context = {
        "order": order,
        "seller": seller,
        "seller_profile": seller_profile,
    }

    return render(request, "marketplace/gcash_payment.html", context)


# -------------------------
# Profile
# -------------------------
@login_required
def profile(request):
    seller = request.user
    profile_obj, _ = Profile.objects.get_or_create(user=seller)
    products = Product.objects.filter(seller=seller).order_by('-date_posted')

    return render(request, "marketplace/profile.html", {
        'profile_user': seller,
        'profile': profile_obj,
        'products': products,
        'is_self': True,
        'is_following': False,
    })


@login_required
def edit_profile(request):
    profile_obj, _ = Profile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        profile_obj.nickname = request.POST.get("nickname", profile_obj.nickname)
        profile_obj.contact_number = request.POST.get("contact_number", profile_obj.contact_number)
        profile_obj.gcash_account = request.POST.get("gcash_account", profile_obj.gcash_account)

        if "avatar" in request.FILES:
            profile_obj.avatar = request.FILES["avatar"]
        if "gcash_qr" in request.FILES:
            profile_obj.gcash_qr = request.FILES["gcash_qr"]

        profile_obj.save()
        messages.success(request, "Profile updated successfully!")
        return redirect("profile")

    return render(request, "marketplace/edit_profile.html", {"profile": profile_obj})


@login_required
def view_user_profile(request, user_id):
    seller = get_object_or_404(User, id=user_id)
    profile_obj, _ = Profile.objects.get_or_create(user=seller)
    products = Product.objects.filter(seller=seller).order_by('-date_posted')

    is_self = (request.user == seller)
    is_following = Follow.objects.filter(follower=request.user, following=seller).exists() if not is_self else False

    return render(request, "marketplace/profile.html", {
        'profile_user': seller,
        'profile': profile_obj,
        'products': products,
        'is_self': is_self,
        'is_following': is_following,
    })

# -------------------------
# FOLLOW SYSTEM
# -------------------------
@login_required
def follow_toggle(request, user_id):
    if request.method != "POST":
        return redirect('view_user_profile', user_id=user_id)

    target = get_object_or_404(User, id=user_id)

    if target == request.user:
        return redirect('view_user_profile', user_id=user_id)

    follow_qs = Follow.objects.filter(follower=request.user, following=target)

    if follow_qs.exists():
        follow_qs.delete()
        messages.info(request, f"You unfollowed {target.username}.")
    else:
        try:
            Follow.objects.create(follower=request.user, following=target)
            messages.success(request, f"You are now following {target.username}.")
        except IntegrityError:
            pass

    return redirect('view_user_profile', user_id=user_id)


# -------------------------
# Followers / Following lists
# -------------------------
@login_required
def followers_list(request, user_id):
    user_obj = get_object_or_404(User, id=user_id)
    followers = User.objects.filter(following_set__following=user_obj).distinct()
    return render(request, "marketplace/followers_list.html", {
        'profile_user': user_obj,
        'followers': followers,
    })


@login_required
def following_list(request, user_id):
    user_obj = get_object_or_404(User, id=user_id)
    following = User.objects.filter(followers_set__follower=user_obj).distinct()
    return render(request, "marketplace/following_list.html", {
        'profile_user': user_obj,
        'following': following,
    })

# -------------------------
# Activity log
# -------------------------
@login_required
def activity_log(request):
    logs = ActivityLog.objects.filter(user=request.user).order_by('-timestamp')
    return render(request, "marketplace/activity_log.html", {'logs': logs})


# -------------------------
# CHAT: Sidebar / create thread / messages
# -------------------------
@login_required
@require_GET
def chat_sidebar_data(request):
    user = request.user

    try:
        following_qs = User.objects.filter(followers_set__follower=user).distinct()
    except Exception:
        following_qs = User.objects.exclude(id=user.id)[:10]

    followers_list = [
        {"id": u.id, "username": u.username, "avatar": getattr(getattr(u, "profile", None), "avatar.url", None)}
        for u in following_qs[:12]
    ]

    suggested_qs = User.objects.exclude(id__in=[user.id] + [u["id"] for u in followers_list])[:12]
    suggested = [{"id": u.id, "username": u.username, "avatar": getattr(getattr(u, "profile", None), "avatar.url", None)} for u in suggested_qs]

    threads = []
    qs = ChatThread.objects.filter(participants=user).order_by("-created_at")[:12]
    for t in qs:
        other = t.other_user(user)
        threads.append({
            "id": t.id,
            "other_id": other.id if other else None,
            "other_username": other.username if other else "Group",
            "last": t.messages.first().text if t.messages.exists() else ""
        })

    return JsonResponse({"followers": followers_list, "suggested": suggested, "threads": threads})


@login_required
@require_POST
def create_or_get_thread(request, user_id):
    user = request.user
    other = get_object_or_404(User, id=user_id)

    # avoid self chat
    if other == user:
        return JsonResponse({"error": "self_chat"}, status=400)

    # find existing thread (simple)
    qs = ChatThread.objects.filter(participants=user).filter(participants=other).distinct()

    if qs.exists():
        thread = qs.first()
    else:
        thread = ChatThread.objects.create()
        thread.participants.add(user, other)

    return JsonResponse({
        "thread_id": thread.id,
        "conversation_id": thread.id,  # ADD THIS
        "id": thread.id,               # ADD THIS
        "username": other.username
    })


@login_required
@require_GET
def thread_messages(request, thread_id):
    """
    Return messages for a ChatThread (oldest -> newest)
    """
    try:
        thread = ChatThread.objects.get(id=thread_id, participants=request.user)
    except ChatThread.DoesNotExist:
        return HttpResponseForbidden()

    N = int(request.GET.get("limit", 50))
    msgs = thread.messages.all().order_by("-timestamp")[:N]
    msgs = list(reversed(list(msgs)))
    data = []
    for m in msgs:
        data.append({
            "id": m.id,
            "sender_id": m.sender.id,
            "sender_username": m.sender.username,
            "text": m.text,
            "timestamp": m.timestamp.isoformat(),
        })
    return JsonResponse({"messages": data})

@login_required
def chat_contacts(request):
    user = request.user

    # People the user follows
    following = User.objects.filter(followers_set__follower=user)

    # People who follow the user
    followers = User.objects.filter(following_set__following=user)

    # Combine both (unique)
    friends = (following | followers).exclude(id=user.id).distinct()

    contacts = []
    for u in friends:
        avatar = None
        if hasattr(u, "profile") and u.profile.avatar:
            avatar = u.profile.avatar.url

        contacts.append({
            "id": u.id,
            "username": u.username,
            "avatar": avatar,
            "unread": 0,
            "preview": "",
        })

    return JsonResponse({"contacts": contacts})

@login_required
def mark_messages_read(request, thread_id):
    try:
        thread = ChatThread.objects.get(id=thread_id, participants=request.user)
    except ChatThread.DoesNotExist:
        return JsonResponse({"error": "not allowed"}, status=403)

    msgs = ChatMessage.objects.filter(thread=thread, read=False).exclude(sender=request.user)

    for msg in msgs:
        msg.read = True
        msg.save()

    return JsonResponse({"status": "ok"})

