# marketplace/urls.py
from django.urls import path
from . import views
from . import views as marketplace_views

urlpatterns = [
    # Home / main pages
    path("", views.home, name="home"),
    path('login/', views.login_signup, name='login'),
    path('marketplace/', views.marketplace, name='marketplace'),
    path('logout/', views.logout_view, name='logout'),

    # Products
    path('add-product/', views.add_product, name='add_product'),
    path('edit/<int:product_id>/', views.edit_product, name='edit_product'),
    path('delete/<int:product_id>/', views.delete_product, name='delete_product'),

    # Cart
    path('cart/', views.view_cart, name='view_cart'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/update/<int:item_id>/', views.update_cart, name='update_cart'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/confirm/<int:order_id>/', views.confirm_order, name='confirm_order'),
    path('cart/complete/<int:order_id>/', views.complete_payment, name='complete_payment'),
    path('checkout/single/<int:item_id>/', views.checkout_single, name='checkout_single'),

    # Profiles
    path('profile/', views.profile, name='profile'),
    path('edit-profile/', views.edit_profile, name='edit_profile'),
    path('user/<int:user_id>/', views.view_user_profile, name='view_user_profile'),

    # Following
    path('user/<int:user_id>/follow/', views.follow_toggle, name='follow_toggle'),
    path('user/<int:user_id>/followers/', views.followers_list, name='followers_list'),
    path('user/<int:user_id>/following/', views.following_list, name='following_list'),

    # GCash
    path('gcash/<int:order_id>/', views.show_gcash_qr, name='show_gcash_qr'),
    path('payment/success/<int:order_id>/', views.payment_success, name='payment_success'),

    # Activity log
    path('activity/log/', views.activity_log, name='activity_log'),

    # Start or get existing conversation
    # Start or get existing conversation (1-on-1 chat)
    path("chat/start/<int:user_id>/", views.create_or_get_thread, name="start_conversation"),
    path("chat/messages/<int:thread_id>/", views.thread_messages, name="thread_messages"),
    path("chat/read/<int:thread_id>/", views.mark_messages_read, name="mark_messages_read"),
    path("chat/contacts/", views.chat_contacts, name="chat_contacts"),

]
