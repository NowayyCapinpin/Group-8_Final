from django import forms
from .models import Profile
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'quantity', 'image']


class OrderConfirmForm(forms.Form):
    name = forms.CharField(max_length=100, required=True)
    contact_number = forms.CharField(max_length=20, required=True)
    gmail = forms.EmailField(required=True)
    program = forms.CharField(max_length=50, required=True)
