from django.contrib import admin
from .models import Profile
from django.contrib.admin.sites import AlreadyRegistered

# Register Profile safely to avoid "already registered" errors during autoreload
try:
    admin.site.register(Profile)
except AlreadyRegistered:
    # already registered (e.g., during autoreload) — ignore
    pass
